		<nav>
			<ul>
				<li><a href="index.php"><i class="fas fa-home"></i>Inicio</a></li>
			<?php 
				if($_SESSION['rol'] == 1){
			 ?>
				<li class="principal">

					<a href="#"><i class="fas fa-users"></i>Usuarios</a>
					<ul>
						<li><a href="Registro_usuario.php"><i class="fas fa-user-plus"></i>Nuevo Usuario</a></li>
						<li><a href="Lista_usuarios.php"><i class="fas fa-list-alt"></i>Lista de Usuarios</a></li>
					</ul>
				</li>
			<?php } ?>
						
				<li class="principal">
					<a href="#"><i class ="fas fa-cubes"></i>Productos</a>
					<ul>
					    <?php 
				            if($_SESSION['rol'] == 1){
			            ?>
					
						<li><a href="Registro_producto.php"><i class= "fas fa-plus"></i>Nuevo Producto</a></li>
							<?php } ?>
						<li><a href="Lista_productos.php"><i class="fas fa-list-alt"></i> Lista de Productos</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#"><i class="far fa-file-alt"></i>recibo</a>
					<ul>
						<?php 
								if($_SESSION['rol'] == 2){
							?>
						<li><a href="recibo_compra.php"><i class="far fa-file-alt"></i>recibo</a></li>
						<?php } ?>
						<?php 
								if($_SESSION['rol'] == 1){
							?>
						<li><a href="recibo_compra.php"><i class="far fa-file-alt"></i>recibos</a></li>
						<?php } ?>
					</ul>
				</li>
			</ul>
		</nav>