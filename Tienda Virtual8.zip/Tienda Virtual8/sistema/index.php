<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Tienda Virtual</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
	<img src="img/PANTALLA DE INICIO.jpg" alt="">


	</section>
	<?php include "includes/footer.php"; ?>
</body>
</html>